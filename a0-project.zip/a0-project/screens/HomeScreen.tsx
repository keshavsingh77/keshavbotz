import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

const API_KEY = '2dca580c2a14b55200e784d157207b4d';
const BASE_URL = 'https://api.themoviedb.org/3';
const IMAGE_BASE_URL = 'https://image.tmdb.org/t/p/original';
const WINDOW_WIDTH = Dimensions.get('window').width;

export default function HomeScreen() {
  const [featured, setFeatured] = useState(null);
  const [trending, setTrending] = useState([]);
  const [popular, setPopular] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMovies();
  }, []);

  const fetchMovies = async () => {
    try {
      const [trendingRes, popularRes, topRatedRes] = await Promise.all([
        fetch(`${BASE_URL}/trending/movie/day?api_key=${API_KEY}`),
        fetch(`${BASE_URL}/movie/popular?api_key=${API_KEY}`),
        fetch(`${BASE_URL}/movie/top_rated?api_key=${API_KEY}`),
      ]);

      const trendingData = await trendingRes.json();
      const popularData = await popularRes.json();
      const topRatedData = await topRatedRes.json();

      setFeatured(trendingData.results[0]);
      setTrending(trendingData.results.slice(1));
      setPopular(popularData.results);
      setTopRated(topRatedData.results);
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  const MovieRow = ({ title, data }) => (
    <View style={styles.movieRow}>
      <Text style={styles.rowTitle}>{title}</Text>
      <FlatList
        horizontal
        data={data}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.movieCard}>
            <Image
              source={{ uri: `${IMAGE_BASE_URL}${item.poster_path}` }}
              style={styles.moviePoster}
            />
          </TouchableOpacity>
        )}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color="#E50914" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Featured Movie */}
        <View style={styles.featuredContainer}>
          <Image
            source={{ uri: `${IMAGE_BASE_URL}${featured?.backdrop_path}` }}
            style={styles.featuredImage}
          />
          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.8)', '#000']}
            style={styles.gradient}
          />
          <View style={styles.featuredContent}>
            <Text style={styles.featuredTitle}>{featured?.title}</Text>
            <View style={styles.buttonRow}>
              <TouchableOpacity style={styles.playButton}>
                <Ionicons name="play" size={24} color="#000" />
                <Text style={styles.playButtonText}>Play</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.myListButton}>
                <Ionicons name="add" size={24} color="#FFF" />
                <Text style={styles.myListButtonText}>My List</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Movie Lists */}
        <View style={styles.listsContainer}>
          <MovieRow title="Trending Now" data={trending} />
          <MovieRow title="Popular on Netflix" data={popular} />
          <MovieRow title="Top Rated" data={topRated} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  featuredContainer: {
    height: 500,
    width: '100%',
  },
  featuredImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  gradient: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  featuredContent: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    padding: 20,
  },
  featuredTitle: {
    color: '#FFF',
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  playButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 4,
    marginRight: 15,
  },
  playButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  myListButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#333',
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 4,
  },
  myListButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  listsContainer: {
    marginTop: -20,
  },
  movieRow: {
    marginBottom: 20,
  },
  rowTitle: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
    marginBottom: 10,
  },
  movieCard: {
    marginHorizontal: 5,
  },
  moviePoster: {
    width: WINDOW_WIDTH * 0.3,
    height: WINDOW_WIDTH * 0.45,
    borderRadius: 4,
  },
});